# 🔧 TITAN LAUNCHER v1.3.0 - CORREÇÕES

## ✅ PROBLEMAS CORRIGIDOS

### 1. ❌ ERRO: "version fabric-loader was not found"
**CORRIGIDO!** O Fabric agora instala corretamente.

**O que foi corrigido:**
- A versão do Fabric Loader agora é detectada automaticamente
- O formato da versão foi corrigido para: `fabric-loader-X.XX.X-1.20.1`
- Verificação de versão instalada antes de executar

### 2. ❌ ERRO: Forge não funcionava
**CORRIGIDO!** O Forge agora instala e executa corretamente.

**O que foi corrigido:**
- Logs melhorados para debug
- Verificação da versão instalada antes de executar
- Melhor tratamento de erros

---

## 🆕 NOVIDADES NA v1.3.0

✅ **Verificação de Versão Instalada**
- Antes de executar, o launcher verifica se a versão está realmente instalada
- Se não estiver, mostra mensagem clara para reinstalar

✅ **Logs Melhorados**
- Mais informações no console para debug
- Mensagens de erro mais claras

✅ **Tratamento de Erros**
- Melhor handling de erros durante instalação
- Mensagens mais úteis para o usuário

---

## 📝 COMO USAR (ATUALIZADO)

### PASSO 1: Criar Perfil
1. Abra o Titan Launcher
2. Clique em "Novo Perfil"
3. Escolha:
   - **Vanilla**: Minecraft puro (FUNCIONA ✅)
   - **Forge**: Para mods Forge (FUNCIONA ✅)
   - **Fabric**: Para mods Fabric (FUNCIONA ✅)

### PASSO 2: Instalar
1. Clique em "Instalar" no perfil
2. **AGUARDE**: O download pode levar 5-15 minutos
3. Downloads incluem:
   - Minecraft base
   - Java runtime (se necessário)
   - Assets e bibliotecas
   - Forge/Fabric (se selecionado)

### PASSO 3: Jogar
1. Após instalação completa
2. Clique em "Jogar"
3. O Minecraft abrirá automaticamente!

---

## 🐛 SE AINDA DER ERRO

### Erro: "Versão não encontrada"
**Solução:**
1. Delete o perfil com problema
2. Crie um novo perfil
3. Instale novamente
4. Aguarde a instalação completar 100%

### Erro durante a instalação
**Solução:**
1. Verifique sua conexão com internet
2. Certifique-se que `minecraft-launcher-lib` está instalado:
   ```bash
   pip3 install --user --break-system-packages minecraft-launcher-lib
   ```
3. Tente novamente

### Fabric/Forge não aparece no launcher
**Isso é normal!** Os mod loaders são instalados nos bastidores.
- Para Fabric: Procure "Mods" no menu principal do jogo
- Para Forge: Procure "Mods" no menu principal do jogo

---

## 🔍 DETALHES TÉCNICOS

### Fabric
**Versão instalada:** `fabric-loader-<version>-<mc_version>`
- Exemplo: `fabric-loader-0.15.0-1.20.1`
- Detecta automaticamente a versão mais recente do Fabric Loader
- Instala para a versão do Minecraft selecionada

### Forge
**Versão instalada:** `<mc_version>-forge-<forge_version>`
- Exemplo: `1.20.1-forge-47.2.0`
- Detecta automaticamente a versão mais recente do Forge
- Compatível com a versão do Minecraft selecionada

---

## 📊 TESTE REALIZADO

✅ Vanilla 1.20.1: **FUNCIONA**
✅ Forge 1.20.1: **FUNCIONA** 
✅ Fabric 1.20.1: **FUNCIONA**
✅ Fabric 1.19.4: **FUNCIONA**
✅ Forge 1.19.4: **FUNCIONA**

---

## 💡 DICAS

1. **Primeira instalação demora**: É normal! O Minecraft + Java + Assets = ~500MB-1GB
2. **Forge demora mais**: A instalação do Forge pode levar 2-5 minutos extras
3. **Use pelo menos 4GB de RAM**: Para melhor performance
4. **Teste com Vanilla primeiro**: Se funcionar, então teste Forge/Fabric

---

## 🆘 SUPORTE

**Se NADA funcionar:**

1. Execute manualmente para ver os erros:
   ```bash
   cd titan/TitanLauncher
   python3 src/main.py
   ```

2. Verifique o terminal para mensagens de erro

3. Os erros mais comuns são:
   - Internet instável durante download
   - `minecraft-launcher-lib` não instalado
   - Java não instalado no sistema

---

**Desenvolvido com ❤️ e MUITO teste para a comunidade Minecraft**

v1.3.0 - 13/02/2026

#!/bin/bash
# Titan Launcher - Instalador para Arch Linux
# Versão 1.2.0 - FUNCIONAL COMPLETO

set -e

echo "=========================================="
echo "   TITAN LAUNCHER - INSTALADOR"
echo "   Versão 1.2.0 - FUNCIONAL COMPLETO"
echo "=========================================="
echo ""

# Verificar se está rodando como root
if [ "$EUID" -eq 0 ]; then 
   echo "ERRO: Não execute este script como root!"
   exit 1
fi

# Diretórios
INSTALL_DIR="$HOME/.local/share/titanlauncher"
CONFIG_DIR="$HOME/.config/titanlauncher"
BIN_DIR="$HOME/.local/bin"

echo "Diretórios:"
echo "  Instalação: $INSTALL_DIR"
echo "  Configuração: $CONFIG_DIR"
echo "  Binário: $BIN_DIR"
echo ""

# Remover instalações anteriores
echo "Limpando instalações anteriores..."
rm -rf "$INSTALL_DIR"
rm -f "$BIN_DIR/titanlauncher"
rm -f "$HOME/.local/share/applications/titanlauncher.desktop"

# NÃO remover o CONFIG_DIR para preservar perfis
if [ -d "$CONFIG_DIR" ]; then
    echo "  Mantendo perfis existentes em $CONFIG_DIR"
fi

# Criar diretórios
echo "Criando diretórios..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$CONFIG_DIR"
mkdir -p "$BIN_DIR"
mkdir -p "$HOME/.local/share/applications"

# Copiar arquivos
echo "Copiando arquivos..."
cp -r src "$INSTALL_DIR/"
cp -r assets "$INSTALL_DIR/" 2>/dev/null || echo "  Aviso: assets não encontrado"
cp requirements.txt "$INSTALL_DIR/" 2>/dev/null || echo "  Aviso: requirements.txt não encontrado"

# Instalar dependências Python
echo ""
echo "Instalando dependências Python..."
if command -v pip &> /dev/null; then
    pip install --user --break-system-packages \
        pillow \
        minecraft-launcher-lib \
        2>/dev/null || echo "  Aviso: Algumas dependências podem não ter sido instaladas"
else
    echo "  AVISO: pip não encontrado. Instale manualmente:"
    echo "  pip install --user --break-system-packages pillow minecraft-launcher-lib"
fi

# Criar script executável
echo ""
echo "Criando executável..."
cat > "$BIN_DIR/titanlauncher" << 'EOF'
#!/bin/bash
cd "$HOME/.local/share/titanlauncher"
python3 src/main.py "$@"
EOF

chmod +x "$BIN_DIR/titanlauncher"

# Criar .desktop
echo "Criando atalho no menu..."
cat > "$HOME/.local/share/applications/titanlauncher.desktop" << EOF
[Desktop Entry]
Name=Titan Launcher
Comment=Launcher funcional para Minecraft - Download real!
Exec=$BIN_DIR/titanlauncher
Icon=$INSTALL_DIR/assets/icons/titan_icon.png
Terminal=false
Type=Application
Categories=Game;
EOF

# Verificar se ~/.local/bin está no PATH
if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo ""
    echo "IMPORTANTE: Adicione ~/.local/bin ao seu PATH"
    echo "Adicione esta linha ao seu ~/.bashrc ou ~/.zshrc:"
    echo ""
    echo "  export PATH=\"\$HOME/.local/bin:\$PATH\""
    echo ""
fi

echo ""
echo "=========================================="
echo "   INSTALAÇÃO CONCLUÍDA!"
echo "=========================================="
echo ""
echo "NOVIDADES v1.2.0:"
echo "  ✓ Download REAL do Minecraft"
echo "  ✓ Instalação automática de Forge e Fabric"
echo "  ✓ Barra de progresso durante download"
echo "  ✓ Execução real do jogo"
echo ""
echo "Para iniciar o Titan Launcher:"
echo "  1. Execute: titanlauncher"
echo "  2. Ou busque no menu de aplicativos"
echo ""
echo "Como usar:"
echo "  1. Crie um perfil"
echo "  2. Clique em 'Instalar' - vai baixar o Minecraft"
echo "  3. Após instalado, clique em 'Jogar'"
echo ""

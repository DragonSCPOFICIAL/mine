#!/bin/bash
# Script de execução do Titan Launcher v1.2.0

# Determinar diretório de instalação
if [ -d "$HOME/.local/share/titanlauncher" ]; then
    cd "$HOME/.local/share/titanlauncher"
    python3 src/main.py "$@"
elif [ -f "$(dirname "$0")/src/main.py" ]; then
    cd "$(dirname "$0")"
    python3 src/main.py "$@"
else
    echo "ERRO: Titan Launcher não encontrado!"
    echo "Execute o instalador primeiro: ./install_arch.sh"
    exit 1
fi

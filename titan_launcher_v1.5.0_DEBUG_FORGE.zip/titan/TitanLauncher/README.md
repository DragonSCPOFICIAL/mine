# TITAN LAUNCHER v1.2.0 - FUNCIONAL COMPLETO

**Download e execução REAL do Minecraft!**

---

## NOVIDADES v1.2.0

### Download REAL do Minecraft
- Clique em "Instalar" e o Minecraft é baixado automaticamente
- Barra de progresso mostrando o download
- Instalação completa de Vanilla, Forge ou Fabric
- Ao terminar, clique em "Jogar" e o jogo inicia!

### Funcionalidades Implementadas
- Download automático do Minecraft
- Instalação de mod loaders (Forge e Fabric)
- Barra de progresso durante instalação
- Execução real do jogo com configurações personalizadas
- Gerenciamento de perfis com status de instalação
- Configuração de RAM por perfil
- Nome de usuário personalizável

---

## INSTALAÇÃO RÁPIDA

```bash
# Extrair
unzip TitanLauncher_v1.2.0_FUNCIONAL.zip
cd TitanLauncher

# Instalar
chmod +x install_arch.sh
./install_arch.sh

# Executar
titanlauncher
```

---

## COMO USAR

### 1. Criar um Perfil

- Clique em "Criar Novo Perfil"
- Preencha:
  - **Nome do Perfil**: Ex: "Minecraft Survival"
  - **Nome de Usuário**: Seu nome no jogo (Ex: "Steve")
  - **Versão**: Escolha a versão (1.20.1, 1.19.4, etc)
  - **Mod Loader**: vanilla, forge ou fabric
  - **RAM**: Quantidade de memória (recomendado: 4GB)
- Clique em "Salvar"

### 2. Instalar o Minecraft

- Na lista de perfis, clique em **"Instalar"**
- Uma janela de progresso aparecerá
- O launcher irá:
  - Baixar o Minecraft da versão escolhida
  - Instalar Forge ou Fabric (se selecionado)
  - Configurar todos os arquivos necessários
- **Aguarde** - pode demorar alguns minutos dependendo da internet
- Quando terminar, aparecerá "Instalação Concluída"

### 3. Jogar

- Após instalado, o botão muda para **"Jogar"**
- Clique em "Jogar"
- O Minecraft abrirá em uma nova janela!
- Divirta-se!

---

## RECURSOS

### Funcionando Completamente
- ✅ Download real do Minecraft
- ✅ Instalação de Vanilla
- ✅ Instalação de Forge
- ✅ Instalação de Fabric
- ✅ Execução do jogo
- ✅ Múltiplos perfis
- ✅ Configuração de RAM
- ✅ Nome de usuário personalizado
- ✅ Status de instalação
- ✅ Barra de progresso

### Versões Suportadas
- Minecraft 1.21.4 até 1.8.9
- Forge (para versões compatíveis)
- Fabric (para versões compatíveis)

---

## REQUISITOS

### Sistema
- Linux (testado no Arch Linux)
- Python 3.8 ou superior
- Conexão com internet (para download)
- ~2GB de espaço em disco por perfil

### Dependências Python
- minecraft-launcher-lib
- pillow
- tkinter (geralmente já vem com Python)

Instaladas automaticamente pelo instalador.

---

## ESTRUTURA DE ARQUIVOS

```
~/.local/share/titanlauncher/           # Programa
├── src/
│   └── main.py                         # Código principal
└── assets/

~/.config/titanlauncher/                # Dados do usuário
├── minecraft/                          # Instalações do Minecraft
│   ├── Perfil1/                        # Cada perfil tem sua pasta
│   ├── Perfil2/
│   └── ...
├── profiles.json                       # Perfis salvos
└── launcher_config.json                # Configurações

~/.local/bin/titanlauncher              # Executável
```

---

## PERGUNTAS FREQUENTES

### O Minecraft realmente baixa?
**Sim!** Esta versão baixa o Minecraft dos servidores oficiais da Mojang usando a biblioteca minecraft-launcher-lib.

### Quanto demora para instalar?
Depende da sua conexão. Normalmente:
- Vanilla: 2-5 minutos
- Forge: 5-10 minutos
- Fabric: 3-7 minutos

### Preciso de conta Microsoft?
**Não!** Esta versão funciona offline com qualquer nome de usuário. Você joga localmente sem login.

### Posso ter múltiplos perfis?
**Sim!** Crie quantos perfis quiser, cada um com versão e configurações diferentes.

### Posso jogar em servidores online?
**Não** - esta versão funciona apenas offline. Para jogar online você precisa do launcher oficial com conta Microsoft.

### Onde ficam os saves?
Em `~/.config/titanlauncher/minecraft/[NOME_DO_PERFIL]/saves`

### Como adicionar mods?
Para Forge/Fabric:
1. Baixe o mod (.jar)
2. Coloque em `~/.config/titanlauncher/minecraft/[PERFIL]/mods/`
3. Inicie o jogo normalmente

### O jogo não inicia. O que fazer?
1. Verifique se tem Java instalado: `java -version`
2. No Arch: `sudo pacman -S jre-openjdk`
3. Tente reinstalar o perfil (exclua e crie novamente)
4. Verifique os logs no terminal

---

## DESINSTALAR

```bash
# Remover programa
rm -rf ~/.local/share/titanlauncher
rm -f ~/.local/bin/titanlauncher
rm -f ~/.local/share/applications/titanlauncher.desktop

# Remover dados (CUIDADO: remove perfis e saves)
rm -rf ~/.config/titanlauncher
```

---

## SOLUÇÃO DE PROBLEMAS

### "minecraft_launcher_lib não encontrado"
```bash
pip install --user --break-system-packages minecraft-launcher-lib
```

### "Erro ao baixar Minecraft"
- Verifique sua conexão com internet
- Tente novamente mais tarde
- Alguns firewalls podem bloquear

### "Java não encontrado"
```bash
# Arch Linux
sudo pacman -S jre-openjdk

# Verificar
java -version
```

### Botão "Instalar" não funciona
- Execute pelo terminal: `titanlauncher`
- Veja as mensagens de erro
- Reinstale: `./install_arch.sh`

### Download para no meio
- Verifique espaço em disco
- Verifique conexão
- Exclua o perfil e crie novamente

---

## CHANGELOG

### v1.2.0 (13/02/2026)
- ✅ NOVO: Download real do Minecraft
- ✅ NOVO: Instalação de Forge
- ✅ NOVO: Instalação de Fabric
- ✅ NOVO: Barra de progresso
- ✅ NOVO: Execução real do jogo
- ✅ NOVO: Campo de username
- ✅ NOVO: Status de instalação
- ✅ Melhorias na interface

### v1.1.0 (13/02/2026)
- ✅ Correção: Botões funcionando
- ✅ Removido ttkbootstrap
- ✅ Interface em tkinter puro

---

## CRÉDITOS

**Desenvolvimento:** Titan Launcher Team  
**Versão Funcional:** Claude (Anthropic)  
**Data:** 13 de Fevereiro de 2026  
**Versão:** 1.2.0 - Funcional Completo

---

## IMPORTANTE

Este launcher é para uso **offline** e **educacional**. Para jogar Minecraft online legalmente, compre o jogo em minecraft.net e use o launcher oficial.

---

**Aproveite o Titan Launcher - agora com download REAL!** 🎮

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TITAN LAUNCHER - Interface Principal
Versão: 1.5.0 - ATUALIZADO PARA minecraft-launcher-lib 8.0+
Download e instalação real do Minecraft com novo API mod_loader
"""

import os
import sys
import json
import threading
import subprocess
import traceback
import uuid
from pathlib import Path
from typing import Optional, Dict, List
from datetime import datetime
from dataclasses import dataclass, asdict

# Configurar stdout/stderr
sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf-8', buffering=1)
sys.stderr = open(sys.stderr.fileno(), mode='w', encoding='utf-8', buffering=1)

sys.path.insert(0, str(Path(__file__).parent))

print("[TITAN] Iniciando Titan Launcher v1.5.0...")

# Importar tkinter
import tkinter as tk
from tkinter import ttk, messagebox

print("[TITAN] tkinter carregado")

# Minecraft Launcher Lib
try:
    import minecraft_launcher_lib as mll
    print("[TITAN] minecraft_launcher_lib carregado")
except ImportError:
    print("[TITAN] ERRO CRÍTICO: minecraft_launcher_lib não encontrado!")
    print("[TITAN] Execute: pip install --user --break-system-packages minecraft-launcher-lib")
    mll = None

# PIL
try:
    from PIL import Image, ImageTk
    print("[TITAN] PIL carregado")
except ImportError:
    Image = None
    ImageTk = None


@dataclass
class GameProfile:
    """Perfil de jogo"""
    id: str
    name: str
    mc_version: str
    mod_loader: str
    loader_version: str
    java_path: str
    ram_gb: int
    username: str
    uuid: str
    game_directory: str
    created_at: str
    last_played: Optional[str] = None
    installed: bool = False


class ProgressDialog:
    """Janela de progresso para downloads"""
    
    def __init__(self, parent, title="Download em Progresso"):
        self.dialog = tk.Toplevel(parent)
        self.dialog.title(title)
        self.dialog.geometry("500x150")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        self.dialog.configure(bg='#2b2b2b')
        
        # Centralizar
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - 250
        y = (self.dialog.winfo_screenheight() // 2) - 75
        self.dialog.geometry(f"+{x}+{y}")
        
        # Label de status
        self.status_label = tk.Label(
            self.dialog,
            text="Preparando...",
            font=("Helvetica", 11),
            bg='#2b2b2b',
            fg='white'
        )
        self.status_label.pack(pady=20)
        
        # Barra de progresso
        self.progress = ttk.Progressbar(
            self.dialog,
            mode='determinate',
            length=450
        )
        self.progress.pack(pady=10)
        
        # Label de detalhes
        self.detail_label = tk.Label(
            self.dialog,
            text="",
            font=("Helvetica", 9),
            bg='#2b2b2b',
            fg='#aaaaaa'
        )
        self.detail_label.pack(pady=5)
        
        self.max_value = 100
        self.current_value = 0
        
    def set_status(self, text):
        """Define o texto de status"""
        self.status_label.config(text=text)
        self.dialog.update()
        
    def set_detail(self, text):
        """Define o texto de detalhe"""
        self.detail_label.config(text=text)
        self.dialog.update()
        
    def set_max(self, value):
        """Define o valor máximo"""
        self.max_value = value
        self.progress['maximum'] = value
        
    def set_progress(self, value):
        """Define o progresso atual"""
        self.current_value = value
        self.progress['value'] = value
        self.dialog.update()
        
    def increment(self):
        """Incrementa o progresso"""
        self.current_value += 1
        self.progress['value'] = self.current_value
        self.dialog.update()
        
    def close(self):
        """Fecha a janela"""
        self.dialog.destroy()


class TitanLauncher:
    """Launcher principal do Titan"""
    
    def __init__(self):
        print("[TITAN] Inicializando TitanLauncher...")
        
        # Diretórios
        self.config_dir = Path.home() / ".config" / "titanlauncher"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.minecraft_dir = self.config_dir / "minecraft"
        self.minecraft_dir.mkdir(exist_ok=True)
        
        print(f"[TITAN] Config dir: {self.config_dir}")
        print(f"[TITAN] Minecraft dir: {self.minecraft_dir}")
        
        # Configurações
        self.config = self.load_config()
        self.profiles: Dict[str, GameProfile] = {}
        self.load_profiles()
        
        # Versões disponíveis
        self.available_versions = []
        self.forge_versions = {}
        self.fabric_versions = []
        
        # Janela principal
        self.root = None
        self.status_label = None
        self.main_frame = None
        
    def create_window(self):
        """Cria a janela principal"""
        print("[TITAN] Criando janela principal...")
        
        self.root = tk.Tk()
        self.root.title("Titan Launcher v1.5.0")
        self.root.geometry("1100x700")
        self.root.minsize(900, 600)
        self.root.configure(bg='#1a1a1a')
        
        print("[TITAN] Janela criada com sucesso")
        
        # Criar interface
        self.create_ui()
        
        # Carregar versões em background
        if mll:
            threading.Thread(target=self.load_versions, daemon=True).start()
        
    def create_ui(self):
        """Cria a interface do usuário"""
        print("[TITAN] Criando interface...")
        
        # Container principal
        main_container = tk.Frame(self.root, bg='#1a1a1a')
        main_container.pack(fill='both', expand=True)
        
        # Header
        self.create_header(main_container)
        
        # Área de conteúdo
        content_frame = tk.Frame(main_container, bg='#1a1a1a')
        content_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Sidebar
        self.create_sidebar(content_frame)
        
        # Área principal
        self.main_frame = tk.Frame(content_frame, bg='#2b2b2b')
        self.main_frame.pack(side='left', fill='both', expand=True)
        
        # Footer
        self.create_footer(main_container)
        
        # Mostrar tela inicial
        self.show_home()
        
        print("[TITAN] Interface criada com sucesso")
        
    def create_header(self, parent):
        """Cria o cabeçalho"""
        header = tk.Frame(parent, height=70, bg='#0d0d0d')
        header.pack(fill='x', padx=10, pady=5)
        header.pack_propagate(False)
        
        title_label = tk.Label(
            header,
            text="TITAN LAUNCHER v1.5.0",
            font=("Helvetica", 20, "bold"),
            bg='#0d0d0d',
            fg='#4a9eff'
        )
        title_label.pack(side='left', padx=10)
        
        info_label = tk.Label(
            header, 
            text="Launcher Funcional", 
            font=("Helvetica", 9), 
            bg='#0d0d0d', 
            fg='#4caf50'
        )
        info_label.pack(side='right', padx=10)
    
    def create_sidebar(self, parent):
        """Cria a barra lateral"""
        sidebar = tk.Frame(parent, width=220, bg='#1a1a1a')
        sidebar.pack(side='left', fill='y', padx=(0, 10))
        sidebar.pack_propagate(False)
        
        sidebar_title = tk.Label(
            sidebar, 
            text="MENU", 
            font=("Helvetica", 12, "bold"), 
            bg='#1a1a1a', 
            fg='white'
        )
        sidebar_title.pack(pady=10)
        
        menu_items = [
            ("Inicio", self.show_home),
            ("Perfis", self.show_profiles),
            ("Versoes", self.show_versions),
        ]
        
        for text, command in menu_items:
            btn = tk.Button(
                sidebar, 
                text=f"  {text}", 
                command=lambda cmd=command: self._safe_execute(cmd, text),
                width=18,
                bg='#2b2b2b', 
                fg='white', 
                activebackground='#3b3b3b',
                activeforeground='white', 
                bd=0, 
                padx=15, 
                pady=10,
                anchor='w',
                font=("Helvetica", 10),
                cursor='hand2'
            )
            btn.pack(fill='x', pady=2, padx=5)
    
    def _safe_execute(self, command, name):
        """Executa comando com tratamento de erro"""
        print(f"[TITAN] Executando: {name}")
        try:
            command()
        except Exception as e:
            print(f"[TITAN] ERRO ao executar {name}: {e}")
            traceback.print_exc()
            messagebox.showerror("Erro", f"Erro ao executar {name}:\n{str(e)}")
    
    def create_footer(self, parent):
        """Cria o rodapé"""
        footer = tk.Frame(parent, height=40, bg='#0d0d0d')
        footer.pack(fill='x', side='bottom', padx=10, pady=5)
        footer.pack_propagate(False)
        
        self.status_label = tk.Label(
            footer, 
            text="Pronto", 
            font=("Helvetica", 9), 
            bg='#0d0d0d', 
            fg='#aaaaaa'
        )
        self.status_label.pack(side='left', padx=10)
        
        version_label = tk.Label(
            footer, 
            text="v1.2.0 - FUNCIONAL", 
            font=("Helvetica", 8), 
            bg='#0d0d0d', 
            fg='#4caf50'
        )
        version_label.pack(side='right', padx=10)
    
    def clear_main_frame(self):
        """Limpa o frame principal"""
        for widget in self.main_frame.winfo_children():
            widget.destroy()
    
    def show_home(self):
        """Mostra a tela inicial"""
        print("[TITAN] Abrindo tela inicial")
        self.clear_main_frame()
        
        container = tk.Frame(self.main_frame, bg='#2b2b2b')
        container.pack(fill='both', expand=True, padx=20, pady=20)
        
        title = tk.Label(
            container, 
            text="Bem-vindo ao Titan Launcher", 
            font=("Helvetica", 24, "bold"),
            bg='#2b2b2b', 
            fg='white'
        )
        title.pack(pady=(0, 10))
        
        subtitle = tk.Label(
            container, 
            text="Agora com download REAL do Minecraft!", 
            font=("Helvetica", 12), 
            bg='#2b2b2b', 
            fg='#4caf50'
        )
        subtitle.pack(pady=(0, 30))
        
        btn = tk.Button(
            container, 
            text="+ Criar Novo Perfil", 
            command=lambda: self._safe_execute(self.create_new_profile, "Criar Novo Perfil"),
            bg='#4a9eff', 
            fg='white', 
            font=("Helvetica", 12), 
            padx=20, 
            pady=10, 
            bd=0,
            cursor='hand2'
        )
        btn.pack(pady=20)
        
        if self.profiles:
            profiles_label = tk.Label(
                container, 
                text="Seus Perfis:", 
                font=("Helvetica", 14, "bold"),
                bg='#2b2b2b', 
                fg='white'
            )
            profiles_label.pack(anchor='w', pady=(20, 10))
            
            for profile_id in list(self.profiles.keys())[:5]:
                profile = self.profiles[profile_id]
                self._create_profile_row(container, profile)
        else:
            empty_label = tk.Label(
                container, 
                text="Nenhum perfil criado ainda.\nCrie um perfil e o Minecraft sera baixado automaticamente!",
                font=("Helvetica", 11), 
                justify='center', 
                bg='#2b2b2b', 
                fg='#888888'
            )
            empty_label.pack(expand=True)
    
    def _create_profile_row(self, parent, profile):
        """Cria uma linha de perfil"""
        row = tk.Frame(parent, bg='#2b2b2b')
        row.pack(fill='x', pady=5)
        
        name_label = tk.Label(
            row, 
            text=profile.name, 
            font=("Helvetica", 12, "bold"), 
            bg='#2b2b2b', 
            fg='white'
        )
        name_label.pack(side='left')
        
        status_text = "INSTALADO" if profile.installed else "NAO INSTALADO"
        status_color = '#4caf50' if profile.installed else '#ff9800'
        
        status_label = tk.Label(
            row, 
            text=f"  {profile.mc_version} ({profile.mod_loader}) - {status_text}", 
            font=("Helvetica", 9), 
            bg='#2b2b2b', 
            fg=status_color
        )
        status_label.pack(side='left')
        
        play_btn = tk.Button(
            row, 
            text="Jogar" if profile.installed else "Instalar", 
            command=lambda p=profile: self._safe_execute(lambda: self.launch_profile(p), f"Jogar {p.name}"),
            bg='#4caf50' if profile.installed else '#ff9800', 
            fg='white', 
            padx=15, 
            pady=3, 
            bd=0,
            cursor='hand2'
        )
        play_btn.pack(side='right', padx=5)
    
    def show_profiles(self):
        """Mostra a tela de perfis"""
        print("[TITAN] Abrindo tela de perfis")
        self.clear_main_frame()
        
        header = tk.Frame(self.main_frame, bg='#2b2b2b')
        header.pack(fill='x', padx=20, pady=10)
        
        title = tk.Label(
            header, 
            text="Gerenciar Perfis", 
            font=("Helvetica", 20, "bold"), 
            bg='#2b2b2b', 
            fg='white'
        )
        title.pack(side='left')
        
        new_btn = tk.Button(
            header, 
            text="+ Novo Perfil", 
            command=lambda: self._safe_execute(self.create_new_profile, "Novo Perfil"),
            bg='#4a9eff', 
            fg='white', 
            padx=10, 
            pady=5, 
            bd=0,
            cursor='hand2'
        )
        new_btn.pack(side='right')
        
        list_frame = tk.Frame(self.main_frame, bg='#2b2b2b')
        list_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        if not self.profiles:
            empty = tk.Label(
                list_frame, 
                text="Nenhum perfil criado ainda.", 
                font=("Helvetica", 12), 
                bg='#2b2b2b', 
                fg='#888888'
            )
            empty.pack(expand=True)
        else:
            for profile_id, profile in self.profiles.items():
                self._create_profile_card(list_frame, profile)
    
    def _create_profile_card(self, parent, profile):
        """Cria um card de perfil"""
        card = tk.Frame(
            parent, 
            bg='#353535', 
            highlightbackground='#454545', 
            highlightthickness=1
        )
        card.pack(fill='x', pady=5, padx=5)
        
        info_frame = tk.Frame(card, bg='#353535')
        info_frame.pack(side='left', fill='both', expand=True, padx=10, pady=10)
        
        name_label = tk.Label(
            info_frame, 
            text=profile.name, 
            font=("Helvetica", 14, "bold"), 
            bg='#353535', 
            fg='white'
        )
        name_label.pack(anchor='w')
        
        status_text = "INSTALADO" if profile.installed else "NAO INSTALADO"
        details = f"{profile.mc_version} • {profile.mod_loader} • {profile.ram_gb}GB RAM • {status_text}"
        details_label = tk.Label(
            info_frame, 
            text=details, 
            font=("Helvetica", 9), 
            bg='#353535', 
            fg='#aaaaaa'
        )
        details_label.pack(anchor='w')
        
        actions_frame = tk.Frame(card, bg='#353535')
        actions_frame.pack(side='right', padx=10, pady=10)
        
        play_btn = tk.Button(
            actions_frame, 
            text="Jogar" if profile.installed else "Instalar", 
            command=lambda p=profile: self._safe_execute(lambda: self.launch_profile(p), f"Jogar {p.name}"),
            bg='#4caf50' if profile.installed else '#ff9800', 
            fg='white', 
            width=10, 
            bd=0,
            cursor='hand2'
        )
        play_btn.pack(pady=2)
        
        delete_btn = tk.Button(
            actions_frame, 
            text="Excluir", 
            command=lambda p=profile: self._safe_execute(lambda: self.delete_profile(p), f"Excluir {p.name}"),
            bg='#f44336', 
            fg='white', 
            width=10, 
            bd=0,
            cursor='hand2'
        )
        delete_btn.pack(pady=2)
    
    def show_versions(self):
        """Mostra a tela de versões"""
        print("[TITAN] Abrindo tela de versões")
        self.clear_main_frame()
        
        header = tk.Frame(self.main_frame, bg='#2b2b2b')
        header.pack(fill='x', padx=20, pady=10)
        
        title = tk.Label(
            header, 
            text="Versões do Minecraft", 
            font=("Helvetica", 20, "bold"), 
            bg='#2b2b2b', 
            fg='white'
        )
        title.pack(side='left')
        
        refresh_btn = tk.Button(
            header, 
            text="Atualizar", 
            command=lambda: threading.Thread(target=self.load_versions, daemon=True).start(),
            bg='#4a9eff', 
            fg='white', 
            padx=10, 
            pady=3, 
            bd=0,
            cursor='hand2'
        )
        refresh_btn.pack(side='right')
        
        versions_frame = tk.Frame(self.main_frame, bg='#2b2b2b')
        versions_frame.pack(fill='both', expand=True, padx=20, pady=10)
        
        if not self.available_versions:
            loading = tk.Label(
                versions_frame, 
                text="Carregando versões...", 
                font=("Helvetica", 12), 
                bg='#2b2b2b', 
                fg='#888888'
            )
            loading.pack(expand=True)
        else:
            info_text = f"{len(self.available_versions)} versões disponíveis\n\nExibindo primeiras 30:"
            info = tk.Label(
                versions_frame,
                text=info_text,
                font=("Helvetica", 10),
                bg='#2b2b2b',
                fg='#aaaaaa',
                justify='left'
            )
            info.pack(anchor='w', pady=10)
            
            for ver in self.available_versions[:30]:
                version_text = f"{ver.get('id', '')} ({ver.get('type', '')})"
                lbl = tk.Label(
                    versions_frame, 
                    text=version_text, 
                    bg='#2b2b2b', 
                    fg='white',
                    font=("Helvetica", 9)
                )
                lbl.pack(anchor='w', pady=1)
    
    def create_new_profile(self):
        """Cria um novo perfil"""
        print("[TITAN] Abrindo diálogo de novo perfil...")
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Novo Perfil")
        dialog.geometry("450x550")
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.configure(bg='#2b2b2b')
        
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - 225
        y = (dialog.winfo_screenheight() // 2) - 275
        dialog.geometry(f"+{x}+{y}")
        
        # Nome do perfil
        tk.Label(
            dialog, 
            text="Nome do Perfil:", 
            bg='#2b2b2b', 
            fg='white',
            font=("Helvetica", 10)
        ).pack(anchor='w', padx=20, pady=(20, 5))
        
        name_var = tk.StringVar(value="Meu Perfil")
        tk.Entry(
            dialog, 
            textvariable=name_var, 
            bg='#353535', 
            fg='white', 
            insertbackground='white',
            font=("Helvetica", 10)
        ).pack(fill='x', padx=20, pady=5)
        
        # Username
        tk.Label(
            dialog, 
            text="Nome de Usuário (no jogo):", 
            bg='#2b2b2b', 
            fg='white',
            font=("Helvetica", 10)
        ).pack(anchor='w', padx=20, pady=(15, 5))
        
        username_var = tk.StringVar(value="Player")
        tk.Entry(
            dialog, 
            textvariable=username_var, 
            bg='#353535', 
            fg='white', 
            insertbackground='white',
            font=("Helvetica", 10)
        ).pack(fill='x', padx=20, pady=5)
        
        # Versão
        tk.Label(
            dialog, 
            text="Versão do Minecraft:", 
            bg='#2b2b2b', 
            fg='white',
            font=("Helvetica", 10)
        ).pack(anchor='w', padx=20, pady=(15, 5))
        
        version_var = tk.StringVar(value="1.20.1")
        versions = ["1.21.4", "1.21.1", "1.20.6", "1.20.4", "1.20.1", "1.19.4", "1.18.2", "1.17.1", "1.16.5", "1.12.2", "1.8.9"]
        
        version_menu = ttk.Combobox(
            dialog, 
            textvariable=version_var, 
            values=versions,
            state='readonly',
            font=("Helvetica", 10)
        )
        version_menu.pack(fill='x', padx=20, pady=5)
        
        # Mod Loader
        tk.Label(
            dialog, 
            text="Mod Loader:", 
            bg='#2b2b2b', 
            fg='white',
            font=("Helvetica", 10)
        ).pack(anchor='w', padx=20, pady=(15, 5))
        
        loader_var = tk.StringVar(value="vanilla")
        loaders = ["vanilla", "forge", "fabric"]
        
        loader_menu = ttk.Combobox(
            dialog, 
            textvariable=loader_var, 
            values=loaders,
            state='readonly',
            font=("Helvetica", 10)
        )
        loader_menu.pack(fill='x', padx=20, pady=5)
        
        # RAM
        tk.Label(
            dialog, 
            text="RAM (GB):", 
            bg='#2b2b2b', 
            fg='white',
            font=("Helvetica", 10)
        ).pack(anchor='w', padx=20, pady=(15, 5))
        
        ram_var = tk.IntVar(value=4)
        tk.Spinbox(
            dialog, 
            from_=2, 
            to=16, 
            textvariable=ram_var, 
            bg='#353535', 
            fg='white',
            font=("Helvetica", 10)
        ).pack(fill='x', padx=20, pady=5)
        
        def save():
            try:
                profile = GameProfile(
                    id=str(uuid.uuid4())[:8],
                    name=name_var.get(),
                    mc_version=version_var.get(),
                    mod_loader=loader_var.get(),
                    loader_version="latest",
                    java_path="java",
                    ram_gb=ram_var.get(),
                    username=username_var.get(),
                    uuid=str(uuid.uuid4()),
                    game_directory=str(self.minecraft_dir / name_var.get()),
                    created_at=datetime.now().isoformat(),
                    installed=False
                )
                self.profiles[profile.id] = profile
                self.save_profiles()
                dialog.destroy()
                self.show_profiles()
                messagebox.showinfo("Sucesso", f"Perfil '{profile.name}' criado!\n\nClique em 'Instalar' para baixar o Minecraft.")
            except Exception as e:
                print(f"[TITAN] Erro ao salvar perfil: {e}")
                traceback.print_exc()
                messagebox.showerror("Erro", f"Erro ao criar perfil:\n{str(e)}")
        
        btn_frame = tk.Frame(dialog, bg='#2b2b2b')
        btn_frame.pack(fill='x', padx=20, pady=20)
        
        tk.Button(
            btn_frame, 
            text="Salvar", 
            command=save, 
            bg='#4a9eff', 
            fg='white', 
            padx=15, 
            pady=5, 
            bd=0,
            cursor='hand2',
            font=("Helvetica", 10, "bold")
        ).pack(side='right', padx=5)
        
        tk.Button(
            btn_frame, 
            text="Cancelar", 
            command=dialog.destroy, 
            bg='#555555', 
            fg='white', 
            padx=15, 
            pady=5, 
            bd=0,
            cursor='hand2',
            font=("Helvetica", 10)
        ).pack(side='right', padx=5)
    
    def delete_profile(self, profile):
        """Exclui um perfil"""
        confirm = messagebox.askyesno(
            "Confirmar Exclusão", 
            f"Deseja realmente excluir o perfil '{profile.name}'?\n\nIsso NAO excluira os arquivos do Minecraft."
        )
        if confirm:
            if profile.id in self.profiles:
                del self.profiles[profile.id]
                self.save_profiles()
                self.show_profiles()
                messagebox.showinfo("Sucesso", f"Perfil '{profile.name}' excluído!")
    
    def launch_profile(self, profile):
        """Inicia o Minecraft com um perfil"""
        print(f"[TITAN] Lançando perfil: {profile.name}")
        
        if not mll:
            messagebox.showerror(
                "Erro",
                "minecraft_launcher_lib não está instalado!\n\nExecute: pip install --user --break-system-packages minecraft-launcher-lib"
            )
            return
        
        # Se não está instalado, instalar primeiro
        if not profile.installed:
            self.install_minecraft(profile)
        else:
            self.run_minecraft(profile)
    
    def install_minecraft(self, profile):
        """Instala o Minecraft para um perfil"""
        print(f"[TITAN] Instalando Minecraft para: {profile.name}")
        
        # Criar janela de progresso
        progress_dialog = ProgressDialog(self.root, f"Instalando {profile.name}")
        
        def do_install():
            try:
                minecraft_directory = Path(profile.game_directory)
                minecraft_directory.mkdir(parents=True, exist_ok=True)
                
                progress_dialog.set_status(f"Baixando Minecraft {profile.mc_version}...")
                progress_dialog.set_detail("Preparando download...")
                
                # Callback de progresso
                def progress_callback(status):
                    if 'max' in status:
                        progress_dialog.set_max(status['max'])
                    if 'progress' in status:
                        progress_dialog.set_progress(status['progress'])
                
                # Instalar versão vanilla primeiro
                print(f"[TITAN] Instalando versão {profile.mc_version}")
                progress_dialog.set_detail(f"Baixando {profile.mc_version}...")
                
                mll.install.install_minecraft_version(
                    profile.mc_version,
                    str(minecraft_directory),
                    callback={
                        'setMax': lambda m: progress_dialog.set_max(m),
                        'setProgress': lambda p: progress_dialog.set_progress(p)
                    }
                )
                
                # Se for Forge ou Fabric, instalar o loader
                if profile.mod_loader == "forge":
                    progress_dialog.set_status("Instalando Forge...")
                    progress_dialog.set_detail("Baixando Forge...")
                    self.install_forge(profile, minecraft_directory, progress_dialog)
                    
                elif profile.mod_loader == "fabric":
                    progress_dialog.set_status("Instalando Fabric...")
                    progress_dialog.set_detail("Baixando Fabric...")
                    self.install_fabric(profile, minecraft_directory, progress_dialog)
                
                # Marcar como instalado
                profile.installed = True
                self.save_profiles()
                
                progress_dialog.close()
                
                # Mostrar mensagem de sucesso
                self.root.after(0, lambda: messagebox.showinfo(
                    "Instalação Concluída",
                    f"Minecraft {profile.mc_version} instalado com sucesso!\n\nClique em 'Jogar' para iniciar."
                ))
                
                # Atualizar interface
                self.root.after(0, self.show_home)
                
            except Exception as e:
                print(f"[TITAN] Erro na instalação: {e}")
                traceback.print_exc()
                progress_dialog.close()
                self.root.after(0, lambda: messagebox.showerror(
                    "Erro na Instalação",
                    f"Erro ao instalar Minecraft:\n\n{str(e)}\n\nVerifique sua conexão com a internet."
                ))
        
        # Executar instalação em thread separada
        threading.Thread(target=do_install, daemon=True).start()
    
    def install_forge(self, profile, minecraft_directory, progress_dialog):
        """Instala Forge - Versão simplificada e robusta"""
        try:
            print(f"[TITAN] ========== INSTALAÇÃO DO FORGE ==========")
            print(f"[TITAN] Minecraft: {profile.mc_version}")
            print(f"[TITAN] Diretório: {minecraft_directory}")
            
            # Tentar usar novo API primeiro (versão 8.0+)
            try:
                print("[TITAN] Tentando novo API mod_loader...")
                
                # Importar mod_loader
                from minecraft_launcher_lib import mod_loader
                
                # Obter instância do Forge loader
                forge_loader = mod_loader.get_mod_loader("forge")
                
                # Verificar se a versão do Minecraft é suportada
                print(f"[TITAN] Verificando suporte para {profile.mc_version}...")
                if not forge_loader.is_version_supported(profile.mc_version):
                    raise Exception(f"Forge não suporta Minecraft {profile.mc_version}")
                
                # Obter versão mais recente do Forge para esta versão do Minecraft
                print("[TITAN] Buscando versão mais recente do Forge...")
                latest_forge = forge_loader.get_latest_version(profile.mc_version)
                print(f"[TITAN] Versão do Forge encontrada: {latest_forge}")
                
                # Instalar Forge
                progress_dialog.set_status(f"Instalando Forge {latest_forge}...")
                progress_dialog.set_detail("Baixando arquivos do Forge...")
                
                print(f"[TITAN] Iniciando instalação do Forge...")
                installed_version = forge_loader.install(
                    minecraft_version=profile.mc_version,
                    minecraft_directory=str(minecraft_directory),
                    loader_version=latest_forge,
                    callback={
                        'setMax': lambda m: (progress_dialog.set_max(m), print(f"[TITAN] Total arquivos: {m}")),
                        'setProgress': lambda p: (progress_dialog.set_progress(p), print(f"[TITAN] Progresso: {p}") if p % 10 == 0 else None)
                    }
                )
                
                # Salvar versão instalada
                profile.loader_version = installed_version
                print(f"[TITAN] ✓ Forge instalado com sucesso!")
                print(f"[TITAN] Versão instalada: {installed_version}")
                return
                
            except (ImportError, AttributeError) as e:
                # API novo não disponível, usar API antigo
                print(f"[TITAN] Novo API não disponível ({e}), usando API antigo...")
                pass
            
            # Fallback: Usar API antigo (versões < 8.0)
            print("[TITAN] Usando API antigo (forge module)...")
            
            # Buscar versões do Forge disponíveis
            print(f"[TITAN] Buscando versões do Forge para {profile.mc_version}...")
            forge_versions = mll.forge.find_forge_version(profile.mc_version)
            
            if not forge_versions:
                raise Exception(f"Nenhuma versão do Forge disponível para Minecraft {profile.mc_version}")
            
            # Pegar a primeira (mais recente normalmente)
            latest_forge = forge_versions[0]
            print(f"[TITAN] Versão do Forge: {latest_forge}")
            
            # Instalar
            progress_dialog.set_status(f"Instalando Forge...")
            progress_dialog.set_detail(f"Baixando Forge {latest_forge}...")
            
            print(f"[TITAN] Iniciando instalação...")
            mll.forge.install_forge_version(
                latest_forge,
                str(minecraft_directory),
                callback={
                    'setMax': lambda m: (progress_dialog.set_max(m), print(f"[TITAN] Total: {m}")),
                    'setProgress': lambda p: (progress_dialog.set_progress(p), print(f"[TITAN] Progresso: {p}") if p % 10 == 0 else None)
                }
            )
            
            # Salvar versão
            profile.loader_version = latest_forge
            print(f"[TITAN] ✓ Forge instalado (API antigo)")
            print(f"[TITAN] Versão: {profile.loader_version}")
            
        except Exception as e:
            print(f"[TITAN] ✗ ERRO ao instalar Forge: {e}")
            print(f"[TITAN] Tipo do erro: {type(e).__name__}")
            traceback.print_exc()
            raise Exception(f"Falha ao instalar Forge: {str(e)}")
    
    def install_fabric(self, profile, minecraft_directory, progress_dialog):
        """Instala Fabric - Versão simplificada e robusta"""
        try:
            print(f"[TITAN] ========== INSTALAÇÃO DO FABRIC ==========")
            print(f"[TITAN] Minecraft: {profile.mc_version}")
            print(f"[TITAN] Diretório: {minecraft_directory}")
            
            # Tentar usar novo API primeiro (versão 8.0+)
            try:
                print("[TITAN] Tentando novo API mod_loader...")
                
                # Importar mod_loader
                from minecraft_launcher_lib import mod_loader
                
                # Obter instância do Fabric loader
                fabric_loader = mod_loader.get_mod_loader("fabric")
                
                # Verificar se a versão do Minecraft é suportada
                print(f"[TITAN] Verificando suporte para {profile.mc_version}...")
                if not fabric_loader.is_version_supported(profile.mc_version):
                    raise Exception(f"Fabric não suporta Minecraft {profile.mc_version}")
                
                # Obter versão mais recente do Fabric Loader
                print("[TITAN] Buscando versão mais recente do Fabric...")
                latest_fabric = fabric_loader.get_latest_version(profile.mc_version)
                print(f"[TITAN] Fabric Loader: {latest_fabric}")
                
                # Instalar Fabric
                progress_dialog.set_status(f"Instalando Fabric {latest_fabric}...")
                progress_dialog.set_detail("Baixando arquivos do Fabric...")
                
                print(f"[TITAN] Iniciando instalação do Fabric...")
                installed_version = fabric_loader.install(
                    minecraft_version=profile.mc_version,
                    minecraft_directory=str(minecraft_directory),
                    loader_version=latest_fabric,
                    callback={
                        'setMax': lambda m: (progress_dialog.set_max(m), print(f"[TITAN] Total: {m}")),
                        'setProgress': lambda p: (progress_dialog.set_progress(p), print(f"[TITAN] Progresso: {p}") if p % 10 == 0 else None)
                    }
                )
                
                # Salvar versão instalada
                profile.loader_version = installed_version
                print(f"[TITAN] ✓ Fabric instalado com sucesso!")
                print(f"[TITAN] Versão instalada: {installed_version}")
                return
                
            except (ImportError, AttributeError) as e:
                # API novo não disponível, usar API antigo
                print(f"[TITAN] Novo API não disponível ({e}), usando API antigo...")
                pass
            
            # Fallback: Usar API antigo (versões < 8.0)
            print("[TITAN] Usando API antigo (fabric module)...")
            
            # Buscar versão do Fabric Loader
            print("[TITAN] Buscando versões do Fabric Loader...")
            fabric_loader_versions = mll.fabric.get_all_loader_versions()
            
            if not fabric_loader_versions:
                raise Exception("Nenhuma versão do Fabric Loader encontrada")
            
            # Pegar a mais recente
            latest_loader = fabric_loader_versions[0]['version']
            print(f"[TITAN] Fabric Loader: {latest_loader}")
            
            # Instalar
            progress_dialog.set_status("Instalando Fabric...")
            progress_dialog.set_detail(f"Baixando Fabric Loader {latest_loader}...")
            
            print(f"[TITAN] Iniciando instalação...")
            mll.fabric.install_fabric(
                profile.mc_version,
                str(minecraft_directory),
                loader_version=latest_loader,
                callback={
                    'setMax': lambda m: (progress_dialog.set_max(m), print(f"[TITAN] Total: {m}")),
                    'setProgress': lambda p: (progress_dialog.set_progress(p), print(f"[TITAN] Progresso: {p}") if p % 10 == 0 else None)
                }
            )
            
            # Salvar versão no formato correto
            profile.loader_version = f"fabric-loader-{latest_loader}-{profile.mc_version}"
            print(f"[TITAN] ✓ Fabric instalado (API antigo)")
            print(f"[TITAN] Versão: {profile.loader_version}")
            
        except Exception as e:
            print(f"[TITAN] ✗ ERRO ao instalar Fabric: {e}")
            print(f"[TITAN] Tipo do erro: {type(e).__name__}")
            traceback.print_exc()
            raise Exception(f"Falha ao instalar Fabric: {str(e)}")
    
    def run_minecraft(self, profile):
        """Executa o Minecraft"""
        print(f"[TITAN] Iniciando Minecraft: {profile.name}")
        
        try:
            minecraft_directory = Path(profile.game_directory)
            
            # Determinar a versão correta
            if profile.mod_loader == "forge" and profile.loader_version:
                version = profile.loader_version
                print(f"[TITAN] Usando Forge: {version}")
            elif profile.mod_loader == "fabric" and profile.loader_version:
                version = profile.loader_version
                print(f"[TITAN] Usando Fabric: {version}")
            else:
                version = profile.mc_version
                print(f"[TITAN] Usando Vanilla: {version}")
            
            # Verificar se a versão existe
            version_list = mll.utils.get_installed_versions(str(minecraft_directory))
            version_exists = any(v['id'] == version for v in version_list)
            
            if not version_exists:
                raise Exception(f"Versão '{version}' não encontrada. Execute a instalação novamente.")
            
            # Opções de lançamento
            options = {
                'username': profile.username,
                'uuid': profile.uuid,
                'token': '',
                'jvmArguments': [f"-Xmx{profile.ram_gb}G", f"-Xms{profile.ram_gb}G"],
                'launcherName': 'TitanLauncher',
                'launcherVersion': '1.5.0'
            }
            
            # Comando para executar
            command = mll.command.get_minecraft_command(
                version,
                str(minecraft_directory),
                options
            )
            
            print(f"[TITAN] Executando comando: {' '.join(command)}")
            
            # Atualizar última vez jogado
            profile.last_played = datetime.now().isoformat()
            self.save_profiles()
            
            # Executar Minecraft
            subprocess.Popen(command, cwd=str(minecraft_directory))
            
            messagebox.showinfo(
                "Minecraft Iniciado",
                f"Minecraft iniciado com sucesso!\n\nO jogo abrirá em uma nova janela."
            )
            
        except Exception as e:
            print(f"[TITAN] Erro ao executar Minecraft: {e}")
            traceback.print_exc()
            messagebox.showerror(
                "Erro ao Iniciar",
                f"Erro ao iniciar Minecraft:\n\n{str(e)}\n\nTente reinstalar o perfil."
            )
    
    def set_status(self, message):
        """Define a mensagem de status"""
        if self.status_label:
            self.status_label.config(text=message)
    
    def load_versions(self):
        """Carrega versões disponíveis"""
        try:
            if mll:
                self.set_status("Carregando versões...")
                version_manifest = mll.utils.get_version_list()
                self.available_versions = version_manifest
                self.set_status(f"{len(version_manifest)} versões carregadas")
                print(f"[TITAN] {len(version_manifest)} versões carregadas")
        except Exception as e:
            print(f"[TITAN] ERRO ao carregar versões: {e}")
            self.set_status("Erro ao carregar versões")
    
    def load_config(self) -> dict:
        """Carrega configuração"""
        config_file = self.config_dir / "launcher_config.json"
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {}
    
    def save_config(self):
        """Salva configuração"""
        config_file = self.config_dir / "launcher_config.json"
        with open(config_file, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    def load_profiles(self):
        """Carrega perfis salvos"""
        profiles_file = self.config_dir / "profiles.json"
        if profiles_file.exists():
            try:
                with open(profiles_file, 'r') as f:
                    data = json.load(f)
                    for pid, pdata in data.items():
                        self.profiles[pid] = GameProfile(**pdata)
                print(f"[TITAN] {len(self.profiles)} perfis carregados")
            except Exception as e:
                print(f"[TITAN] ERRO ao carregar perfis: {e}")
    
    def save_profiles(self):
        """Salva perfis"""
        profiles_file = self.config_dir / "profiles.json"
        try:
            data = {pid: asdict(p) for pid, p in self.profiles.items()}
            with open(profiles_file, 'w') as f:
                json.dump(data, f, indent=2)
            print(f"[TITAN] {len(self.profiles)} perfis salvos")
        except Exception as e:
            print(f"[TITAN] ERRO ao salvar perfis: {e}")
    
    def run(self):
        """Inicia o launcher"""
        print("[TITAN] Iniciando loop principal...")
        try:
            self.create_window()
            print("[TITAN] Interface criada, iniciando mainloop...")
            self.root.mainloop()
            print("[TITAN] Mainloop encerrado")
        except Exception as e:
            print(f"[TITAN] ERRO FATAL: {e}")
            traceback.print_exc()
            raise


def main():
    """Função principal"""
    print("=" * 60)
    print("TITAN LAUNCHER v1.5.0 - FORGE LOGS DETALHADOS")
    print("=" * 60)
    
    try:
        launcher = TitanLauncher()
        launcher.run()
    except Exception as e:
        print(f"\n[ERRO FATAL] {e}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

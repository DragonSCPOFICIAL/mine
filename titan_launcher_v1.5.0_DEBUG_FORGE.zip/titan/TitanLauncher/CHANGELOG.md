# CHANGELOG - TITAN LAUNCHER v1.2.0

## v1.2.0 - FUNCIONAL COMPLETO (13/02/2026)

### 🎉 GRANDE ATUALIZAÇÃO - DOWNLOAD REAL DO MINECRAFT

Esta é a versão mais importante até agora! O Titan Launcher agora **realmente baixa e executa o Minecraft**.

---

### ✨ NOVAS FUNCIONALIDADES

#### 1. Download Real do Minecraft
- **Implementado**: Sistema completo de download do Minecraft
- **Usando**: minecraft-launcher-lib oficial
- **Funciona com**: Todas as versões de 1.21.4 até 1.8.9
- **Download de**: Servidores oficiais da Mojang

#### 2. Instalação de Mod Loaders
- **Forge**: Download e instalação automática
- **Fabric**: Download e instalação automática
- **Vanilla**: Instalação limpa sem mods

#### 3. Barra de Progresso
- Janela dedicada durante instalação
- Progresso em tempo real
- Informações detalhadas do que está sendo baixado
- Mensagens de status (Preparando, Baixando, Instalando)

#### 4. Execução Real do Jogo
- Comando de execução gerado corretamente
- Configuração de RAM aplicada
- Nome de usuário personalizado
- Lançamento em processo separado

#### 5. Sistema de Status
- Perfis mostram se estão INSTALADOS ou NÃO INSTALADOS
- Cor verde para instalado, laranja para não instalado
- Botão muda de "Instalar" para "Jogar" automaticamente

#### 6. Campo de Username
- Adicionar nome de usuário no perfil
- Usado dentro do jogo
- Aparece no multiplayer local

---

### 🔧 IMPLEMENTAÇÕES TÉCNICAS

#### Classe ProgressDialog
```python
class ProgressDialog:
    """Janela de progresso para downloads"""
```
- Janela modal para feedback visual
- Barra de progresso com porcentagem
- Labels de status e detalhes
- Fechamento automático após conclusão

#### Método install_minecraft()
- Download assíncrono em thread separada
- Callbacks para atualização de progresso
- Tratamento de erros robusto
- Instalação de mod loaders condicional

#### Método run_minecraft()
- Geração de comando usando minecraft-launcher-lib
- Configuração de JVM args (RAM)
- Lançamento com subprocess.Popen
- Atualização de "última vez jogado"

#### Sistema de Diretórios
```
~/.config/titanlauncher/
├── minecraft/
│   ├── Perfil1/         # Instalação separada
│   ├── Perfil2/
│   └── ...
├── profiles.json
└── launcher_config.json
```

---

### 📋 MUDANÇAS NO GameProfile

Novos campos adicionados:
```python
@dataclass
class GameProfile:
    username: str           # NOVO: Nome no jogo
    uuid: str              # NOVO: UUID único
    java_path: str         # NOVO: Caminho do Java
    installed: bool        # NOVO: Status de instalação
```

---

### 🎨 MELHORIAS NA INTERFACE

#### Visual
- Status colorido (verde/laranja)
- Botões adaptativos (Instalar/Jogar)
- Informações mais claras
- Versão destacada no footer

#### Usabilidade
- Mensagens de sucesso após instalação
- Confirmação antes de excluir
- Feedback visual durante processos
- Instruções claras

---

### 🐛 CORREÇÕES

#### Da v1.1.0
- ✅ Todos os botões funcionando
- ✅ Interface estável
- ✅ Sem dependências problemáticas

#### Novos Fixes
- ✅ Tratamento de erros durante download
- ✅ Verificação de conexão internet
- ✅ Validação de versões disponíveis
- ✅ Criação de diretórios automática

---

### 📦 DEPENDÊNCIAS

#### Obrigatórias
```
pillow>=10.0.0
minecraft-launcher-lib>=6.0
```

#### Sistema
- Python 3.8+
- Java Runtime (para executar Minecraft)
- tkinter (geralmente incluído)

---

### 🚀 FLUXO DE USO

```
1. Criar Perfil
   ↓
2. Clicar "Instalar"
   ↓
3. [Download em Progresso]
   ├─ Baixar Minecraft
   ├─ Instalar Vanilla
   └─ Instalar Mod Loader (se selecionado)
   ↓
4. [Instalado]
   ↓
5. Clicar "Jogar"
   ↓
6. [Minecraft Inicia]
```

---

### ⚠️ LIMITAÇÕES CONHECIDAS

1. **Sem Autenticação Microsoft**
   - Funciona apenas offline
   - Não pode jogar em servidores online oficiais
   - Multiplayer apenas LAN

2. **Sem Download de Mods**
   - Mods devem ser instalados manualmente
   - Pasta: `~/.config/titanlauncher/minecraft/[perfil]/mods/`

3. **Versões do Forge**
   - Algumas versões antigas podem não ter Forge disponível
   - Verificação durante instalação

4. **Sem OptiFine Integrado**
   - OptiFine deve ser instalado manualmente
   - Compatível com Forge instalado

---

### 📊 COMPARAÇÃO DE VERSÕES

| Recurso | v1.1.0 | v1.2.0 |
|---------|---------|---------|
| Interface Funcional | ✅ | ✅ |
| Criar Perfis | ✅ | ✅ |
| Download Minecraft | ❌ | ✅ |
| Instalar Forge | ❌ | ✅ |
| Instalar Fabric | ❌ | ✅ |
| Executar Jogo | ❌ | ✅ |
| Barra Progresso | ❌ | ✅ |
| Status Instalação | ❌ | ✅ |

---

### 🔮 PRÓXIMAS VERSÕES (Roadmap)

#### v1.3.0 (Planejado)
- [ ] Download de mods do CurseForge
- [ ] Download de mods do Modrinth
- [ ] Gerenciador de mods integrado
- [ ] Atualização automática de mods

#### v1.4.0 (Planejado)
- [ ] Importação de modpacks
- [ ] Criação de modpacks
- [ ] Compartilhamento de perfis

#### v1.5.0 (Planejado)
- [ ] Autenticação Microsoft (talvez)
- [ ] Modo online
- [ ] Skins personalizadas

---

### 📝 NOTAS DE MIGRAÇÃO

#### De v1.1.0 para v1.2.0

**Perfis criados na v1.1.0:**
- Serão mantidos
- Precisam ser reinstalados (não têm Minecraft baixado)
- Campos novos serão adicionados automaticamente

**Processo:**
1. Backup de `~/.config/titanlauncher/profiles.json` (opcional)
2. Instalar v1.2.0 normalmente
3. Perfis antigos aparecerão como "NÃO INSTALADO"
4. Clique em "Instalar" para baixar o Minecraft

---

### 🙏 AGRADECIMENTOS

- **minecraft-launcher-lib**: Por tornar isso possível
- **Comunidade Python**: Pelas bibliotecas excelentes
- **Usuários**: Por testarem e reportarem problemas

---

### 📄 LICENÇA

MIT License (presumida)

---

### 🐛 REPORTAR BUGS

Se encontrar problemas:
1. Execute pelo terminal: `titanlauncher`
2. Anote as mensagens de erro
3. Informe: versão do Python, sistema operacional, erro exato

---

### ✅ CHECKLIST DE TESTES

Antes de lançar, foram testados:

- [x] Criação de perfil Vanilla
- [x] Download de versão 1.20.1
- [x] Download de versão 1.19.4
- [x] Instalação de Forge
- [x] Instalação de Fabric
- [x] Execução do jogo
- [x] Múltiplos perfis
- [x] Exclusão de perfis
- [x] Barra de progresso
- [x] Tratamento de erros
- [x] Persistência de dados

---

**Esta é a versão mais completa do Titan Launcher até agora!**

**Versão:** 1.2.0  
**Data:** 13 de Fevereiro de 2026  
**Status:** Estável e Funcional  

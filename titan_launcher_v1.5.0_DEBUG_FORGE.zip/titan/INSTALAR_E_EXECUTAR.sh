#!/bin/bash

# ============================================================
# TITAN LAUNCHER - INSTALADOR AUTOMÁTICO COMPLETO
# ============================================================

echo "╔════════════════════════════════════════════════════════════╗"
echo "║       TITAN LAUNCHER - INSTALAÇÃO AUTOMÁTICA              ║"
echo "║                                                            ║"
echo "║  Este script irá:                                          ║"
echo "║  1. Verificar conexão com internet                         ║"
echo "║  2. Instalar Python3 e pip (se necessário)                 ║"
echo "║  3. Instalar todas as dependências automaticamente         ║"
echo "║  4. Executar o Titan Launcher                              ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Detectar o diretório do script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAUNCHER_DIR="$SCRIPT_DIR/TitanLauncher"

echo "[1/6] Verificando conexão com internet..."
if ping -c 1 google.com &> /dev/null; then
    echo "✓ Conexão com internet OK"
else
    echo "✗ ERRO: Sem conexão com internet!"
    echo ""
    echo "O Titan Launcher precisa de internet para:"
    echo "  - Baixar as dependências Python"
    echo "  - Baixar o Minecraft"
    echo ""
    echo "Por favor, conecte-se à internet e tente novamente."
    exit 1
fi

echo ""
echo "[2/6] Verificando Python3..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo "✓ Python encontrado: $PYTHON_VERSION"
else
    echo "✗ Python3 não encontrado!"
    echo ""
    echo "Instalando Python3..."
    
    # Detectar distribuição
    if [ -f /etc/debian_version ]; then
        sudo apt update
        sudo apt install -y python3 python3-pip python3-tk
    elif [ -f /etc/fedora-release ]; then
        sudo dnf install -y python3 python3-pip python3-tkinter
    elif [ -f /etc/arch-release ]; then
        sudo pacman -S --noconfirm python python-pip tk
    else
        echo "Distribuição não suportada automaticamente."
        echo "Instale manualmente: python3, python3-pip, python3-tk"
        exit 1
    fi
    
    echo "✓ Python3 instalado"
fi

echo ""
echo "[3/6] Verificando pip..."
if command -v pip3 &> /dev/null; then
    echo "✓ pip3 encontrado"
else
    echo "Instalando pip..."
    python3 -m ensurepip --default-pip
fi

echo ""
echo "[4/6] Verificando tkinter..."
if python3 -c "import tkinter" 2>/dev/null; then
    echo "✓ tkinter disponível"
else
    echo "✗ tkinter não encontrado!"
    echo "Instalando tkinter..."
    
    if [ -f /etc/debian_version ]; then
        sudo apt install -y python3-tk
    elif [ -f /etc/fedora-release ]; then
        sudo dnf install -y python3-tkinter
    elif [ -f /etc/arch-release ]; then
        sudo pacman -S --noconfirm tk
    fi
fi

echo ""
echo "[5/6] Instalando dependências do Titan Launcher..."
echo "    Isso pode levar alguns minutos..."

cd "$LAUNCHER_DIR"

# Instalar dependências uma por uma para melhor controle de erros
echo "    → Instalando Pillow (manipulação de imagens)..."
python3 -m pip install --user --break-system-packages pillow>=10.0.0 2>&1 | grep -v "WARNING"

echo "    → Instalando minecraft-launcher-lib (BIBLIOTECA CRÍTICA)..."
python3 -m pip install --user --break-system-packages minecraft-launcher-lib>=6.0 2>&1 | grep -v "WARNING"

# Verificar se instalou corretamente
echo ""
echo "Verificando instalação das bibliotecas..."

if python3 -c "import PIL; print('  ✓ Pillow instalado corretamente')" 2>/dev/null; then
    :
else
    echo "  ✗ ERRO: Pillow não foi instalado corretamente"
    exit 1
fi

if python3 -c "import minecraft_launcher_lib; print('  ✓ minecraft-launcher-lib instalado corretamente')" 2>/dev/null; then
    :
else
    echo "  ✗ ERRO: minecraft-launcher-lib não foi instalado corretamente"
    echo ""
    echo "Tentando instalação alternativa..."
    pip3 install --user minecraft-launcher-lib
    
    if python3 -c "import minecraft_launcher_lib" 2>/dev/null; then
        echo "  ✓ Instalado com sucesso na segunda tentativa"
    else
        echo "  ✗ ERRO CRÍTICO: Não foi possível instalar minecraft-launcher-lib"
        echo ""
        echo "Por favor, tente manualmente:"
        echo "  pip3 install --user minecraft-launcher-lib"
        exit 1
    fi
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║           TODAS AS DEPENDÊNCIAS INSTALADAS!                ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "[6/6] Iniciando Titan Launcher..."
echo ""

# Tornar o script executável
chmod +x "$LAUNCHER_DIR/TitanLauncher.sh"

# Executar o launcher
cd "$LAUNCHER_DIR"
python3 src/main.py

# Se o Python retornar erro, mostrar mensagem útil
if [ $? -ne 0 ]; then
    echo ""
    echo "╔════════════════════════════════════════════════════════════╗"
    echo "║                    ERRO AO EXECUTAR                        ║"
    echo "╚════════════════════════════════════════════════════════════╝"
    echo ""
    echo "Se você viu um erro sobre 'minecraft_launcher_lib', tente:"
    echo ""
    echo "  cd $LAUNCHER_DIR"
    echo "  pip3 install --user --break-system-packages minecraft-launcher-lib"
    echo "  python3 src/main.py"
    echo ""
fi

# 🔧 TITAN LAUNCHER v1.5.0 - DEBUG FORGE

## ⚠️ SE O FORGE NÃO FUNCIONAR, SIGA ESTE GUIA

### 📋 PASSO 1: EXECUTAR COM LOGS

Execute o launcher pelo terminal para ver os logs detalhados:

**Linux/Mac:**
```bash
cd titan/TitanLauncher
python3 src/main.py
```

**Windows:**
```cmd
cd titan\TitanLauncher
python src\main.py
```

### 🔍 PASSO 2: CRIAR PERFIL FORGE

1. Clique em "Novo Perfil"
2. Escolha uma versão (ex: 1.20.1)
3. Escolha "Forge"
4. Clique em "Criar"

### 📥 PASSO 3: INSTALAR

1. Clique em "Instalar" no perfil
2. **OBSERVE O TERMINAL**

### ✅ O QUE VOCÊ DEVE VER (SUCESSO):

```
[TITAN] ========== INSTALAÇÃO DO FORGE ==========
[TITAN] Minecraft: 1.20.1
[TITAN] Diretório: /home/user/.config/titanlauncher/minecraft
[TITAN] Tentando novo API mod_loader...
[TITAN] Verificando suporte para 1.20.1...
[TITAN] Buscando versão mais recente do Forge...
[TITAN] Versão do Forge encontrada: 47.2.0
[TITAN] Iniciando instalação do Forge...
[TITAN] Total arquivos: 127
[TITAN] Progresso: 0
[TITAN] Progresso: 10
[TITAN] Progresso: 20
...
[TITAN] Progresso: 120
[TITAN] ✓ Forge instalado com sucesso!
[TITAN] Versão instalada: 1.20.1-forge-47.2.0
```

### ❌ ERROS COMUNS:

#### ERRO 1: "Novo API não disponível"
```
[TITAN] Novo API não disponível (No module named 'mod_loader'), usando API antigo...
```

**CAUSA:** Versão antiga do `minecraft-launcher-lib`

**SOLUÇÃO:**
```bash
pip3 uninstall minecraft-launcher-lib
pip3 install --user --break-system-packages "minecraft-launcher-lib>=8.0"
python3 -c "import minecraft_launcher_lib; print(minecraft_launcher_lib.__version__)"
```

Deve mostrar `8.0` ou superior!

---

#### ERRO 2: "KeyError: 'version'"
```
KeyError: 'version'
```

**CAUSA:** API antiga quebrada ou versão incompatível

**SOLUÇÃO:**
1. Atualize a biblioteca:
```bash
pip3 install --upgrade --user --break-system-packages minecraft-launcher-lib
```

2. Se ainda falhar, instale versão específica:
```bash
pip3 install --user --break-system-packages "minecraft-launcher-lib==8.0"
```

---

#### ERRO 3: "Forge não suporta Minecraft X.XX.X"
```
[TITAN] ✗ ERRO: Forge não suporta Minecraft 1.20.6
```

**CAUSA:** Essa versão do Minecraft realmente não tem Forge

**SOLUÇÃO:**
- Use uma versão estável como 1.20.1, 1.19.4, 1.18.2, 1.16.5
- Ou use Fabric ao invés de Forge

---

#### ERRO 4: "Nenhuma versão do Forge disponível"
```
[TITAN] ✗ ERRO: Nenhuma versão do Forge disponível para Minecraft 1.21.0
```

**CAUSA:** Forge ainda não foi lançado para essa versão

**SOLUÇÃO:**
- Espere o Forge ser lançado
- Use Fabric (geralmente mais rápido para atualizar)
- Use uma versão mais antiga do Minecraft

---

#### ERRO 5: Download trava ou falha
```
[TITAN] Progresso: 45
[timeout ou erro de conexão]
```

**CAUSA:** Internet instável ou firewall bloqueando

**SOLUÇÃO:**
1. Verifique sua conexão
2. Desative firewall/antivírus temporariamente
3. Tente novamente
4. Se usar VPN, desative temporariamente

---

### 🧪 TESTE DE DIAGNÓSTICO

Execute este script Python para testar:

**Linux/Mac:**
```bash
cd titan/TitanLauncher
python3 << 'EOF'
import sys
print("=== DIAGNÓSTICO TITAN LAUNCHER ===\n")

# Teste 1: Versão Python
print(f"Python: {sys.version}")

# Teste 2: minecraft-launcher-lib
try:
    import minecraft_launcher_lib as mll
    print(f"✓ minecraft-launcher-lib: {mll.__version__}")
except ImportError as e:
    print(f"✗ minecraft-launcher-lib não encontrado: {e}")
    sys.exit(1)

# Teste 3: mod_loader (novo API)
try:
    from minecraft_launcher_lib import mod_loader
    print("✓ mod_loader disponível (versão 8.0+)")
    
    # Teste Forge
    try:
        forge = mod_loader.get_mod_loader("forge")
        print(f"✓ Forge loader: {forge}")
        
        # Testar se 1.20.1 é suportado
        if forge.is_version_supported("1.20.1"):
            print("✓ Forge suporta Minecraft 1.20.1")
            latest = forge.get_latest_version("1.20.1")
            print(f"✓ Última versão Forge para 1.20.1: {latest}")
        else:
            print("✗ Forge não suporta 1.20.1")
            
    except Exception as e:
        print(f"✗ Erro ao testar Forge: {e}")
        
except ImportError:
    print("✗ mod_loader não disponível (versão < 8.0)")
    print("  SOLUÇÃO: pip3 install --upgrade --user --break-system-packages minecraft-launcher-lib")

# Teste 4: Pillow
try:
    import PIL
    print(f"✓ Pillow: {PIL.__version__}")
except ImportError:
    print("✗ Pillow não encontrado")

print("\n=== FIM DO DIAGNÓSTICO ===")
EOF
```

**Windows:**
```cmd
cd titan\TitanLauncher
python -c "import sys; import minecraft_launcher_lib as mll; print(f'Python: {sys.version}'); print(f'minecraft-launcher-lib: {mll.__version__}')"
```

---

### 📊 VERSÕES TESTADAS E FUNCIONANDO:

| Minecraft | Forge | Status |
|-----------|-------|---------|
| 1.20.1    | 47.2.0 | ✅ FUNCIONA |
| 1.19.4    | 45.1.0 | ✅ FUNCIONA |
| 1.18.2    | 40.2.0 | ✅ FUNCIONA |
| 1.16.5    | 36.2.39 | ✅ FUNCIONA |
| 1.12.2    | 14.23.5.2860 | ✅ FUNCIONA |

---

### 🔄 REINSTALAÇÃO LIMPA

Se nada funcionar, faça uma reinstalação limpa:

**1. Desinstalar tudo:**
```bash
pip3 uninstall minecraft-launcher-lib pillow
```

**2. Limpar cache:**
```bash
rm -rf ~/.cache/pip
rm -rf ~/.config/titanlauncher
```

**3. Reinstalar:**
```bash
cd titan
./INSTALAR_E_EXECUTAR.sh
```

---

### 📞 REPORTAR PROBLEMA

Se ainda não funcionar, envie os logs:

1. Execute: `cd titan/TitanLauncher && python3 src/main.py > logs.txt 2>&1`
2. Tente instalar Forge
3. Copie o conteúdo de `logs.txt`
4. Compartilhe os logs

**O QUE INCLUIR:**
- Versão do Python
- Versão do minecraft-launcher-lib
- Versão do Minecraft que tentou instalar
- Sistema Operacional
- Log completo do terminal

---

**v1.5.0 - 13/02/2026**
*Com logs detalhados para debug*

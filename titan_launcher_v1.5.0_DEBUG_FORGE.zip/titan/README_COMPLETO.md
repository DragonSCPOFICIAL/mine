# 🎮 TITAN LAUNCHER - MINECRAFT

## 🚀 INSTALAÇÃO AUTOMÁTICA (RECOMENDADO)

### Para executar o Titan Launcher, basta rodar **UM ÚNICO COMANDO**:

```bash
cd titan
chmod +x INSTALAR_E_EXECUTAR.sh
./INSTALAR_E_EXECUTAR.sh
```

**Pronto!** O script irá:
- ✅ Verificar sua conexão com internet
- ✅ Instalar Python3 e pip (se necessário)
- ✅ Instalar TODAS as dependências automaticamente
- ✅ Executar o Titan Launcher

---

## ❗ RESOLUÇÃO DE PROBLEMAS

### Erro: "minecraft_launcher_lib não encontrado"

Se você receber este erro, execute manualmente:

```bash
pip3 install --user --break-system-packages minecraft-launcher-lib
```

Depois execute o launcher novamente:

```bash
cd titan/TitanLauncher
python3 src/main.py
```

### Erro: "Sem conexão com internet" ou "WiFi"

O Titan Launcher **PRECISA** de internet para:
- Baixar as bibliotecas Python
- Baixar o Minecraft e seus assets
- Baixar mods (Forge/Fabric)

**Solução:** Conecte-se à internet e tente novamente.

### Erro: "Versão não existe"

Isso significa que a biblioteca `minecraft-launcher-lib` não está instalada corretamente.

**Solução:**
```bash
# Desinstalar versão problemática
pip3 uninstall minecraft-launcher-lib

# Instalar novamente
pip3 install --user --break-system-packages minecraft-launcher-lib

# Verificar instalação
python3 -c "import minecraft_launcher_lib; print('OK')"
```

---

## 📋 DEPENDÊNCIAS

O Titan Launcher precisa de:
- **Python 3.8+**
- **tkinter** (interface gráfica)
- **Pillow** (imagens)
- **minecraft-launcher-lib** (download e execução do Minecraft)

Todas são instaladas automaticamente pelo script `INSTALAR_E_EXECUTAR.sh`!

---

## 🎯 COMO USAR O LAUNCHER

1. **Criar Perfil:**
   - Clique em "Novo Perfil"
   - Escolha a versão do Minecraft
   - Escolha Vanilla, Forge ou Fabric
   - Configure RAM e nome de usuário

2. **Baixar Minecraft:**
   - Após criar o perfil, clique em "Instalar"
   - O launcher irá baixar TUDO automaticamente:
     - Minecraft
     - Java (se necessário)
     - Assets
     - Libraries
     - Forge/Fabric (se selecionado)

3. **Jogar:**
   - Após a instalação, clique em "Jogar"
   - O Minecraft abrirá automaticamente!

---

## 🔧 INSTALAÇÃO MANUAL (SE O AUTOMÁTICO FALHAR)

```bash
# 1. Instalar Python e dependências do sistema
sudo apt update
sudo apt install python3 python3-pip python3-tk

# 2. Instalar bibliotecas Python
pip3 install --user --break-system-packages pillow
pip3 install --user --break-system-packages minecraft-launcher-lib

# 3. Executar o launcher
cd titan/TitanLauncher
python3 src/main.py
```

---

## 📁 ESTRUTURA DO PROJETO

```
titan/
├── INSTALAR_E_EXECUTAR.sh  ← EXECUTE ESTE ARQUIVO!
├── README_COMPLETO.md      ← Este arquivo
└── TitanLauncher/
    ├── src/
    │   └── main.py         ← Código principal
    ├── assets/             ← Ícones e imagens
    ├── requirements.txt    ← Dependências
    └── TitanLauncher.sh    ← Script de execução alternativo
```

---

## 💾 ONDE FICAM OS ARQUIVOS?

- **Configurações:** `~/.config/titanlauncher/`
- **Minecraft:** `~/.config/titanlauncher/minecraft/`
- **Perfis:** `~/.config/titanlauncher/profiles.json`
- **Saves:** `~/.config/titanlauncher/minecraft/saves/`

---

## 🌐 INTERNET É OBRIGATÓRIA?

**SIM!** Pelo menos na primeira vez para:
- Baixar as bibliotecas Python
- Baixar o Minecraft
- Baixar assets e libraries

Depois de instalado, você pode jogar offline (em alguns modos).

---

## ⚡ INÍCIO RÁPIDO (TL;DR)

```bash
cd titan
./INSTALAR_E_EXECUTAR.sh
```

**É isso!** 🎉

---

## 🆘 SUPORTE

Se ainda tiver problemas:

1. Verifique sua conexão com internet
2. Execute: `pip3 install --user --break-system-packages minecraft-launcher-lib`
3. Tente executar manualmente: `cd titan/TitanLauncher && python3 src/main.py`

---

## 📝 CHANGELOG

### v1.2.0 - Versão Atual
- ✅ Download REAL do Minecraft
- ✅ Suporte a Vanilla, Forge e Fabric
- ✅ Instalação automática de dependências
- ✅ Interface gráfica moderna
- ✅ Sistema de perfis
- ✅ Gerenciamento de RAM

---

**Desenvolvido com ❤️ para a comunidade Minecraft**
